export default function AdminPage() {
  return (
    <main className="min-h-screen bg-black text-white p-10">
      <h1 className="text-5xl font-bold mb-10">
        AVISON Admin
      </h1>

      <div className="max-w-xl space-y-4">

        <input
          placeholder="Produktname"
          className="w-full p-4 rounded-2xl bg-zinc-900 border border-zinc-700"
        />

        <input
          placeholder="Preis"
          className="w-full p-4 rounded-2xl bg-zinc-900 border border-zinc-700"
        />

        <input
          placeholder="Bild URL"
          className="w-full p-4 rounded-2xl bg-zinc-900 border border-zinc-700"
        />

        <button className="px-8 py-4 rounded-full bg-white text-black font-bold">
          Produkt hinzufügen
        </button>

      </div>
    </main>
  );
}