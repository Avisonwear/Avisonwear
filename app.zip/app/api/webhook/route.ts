import { NextResponse } from "next/server";
import Stripe from "stripe";
import { createClient } from "@supabase/supabase-js";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

export async function POST(req: Request) {
  try {
    const body = await req.text();

    const sig = req.headers.get("stripe-signature");

    if (!sig) {
      return NextResponse.json(
        { error: "No signature" },
        { status: 400 }
      );
    }

    const event = stripe.webhooks.constructEvent(
      body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET!
    );

   if (event.type === "checkout.session.completed") {
  const session = event.data.object as Stripe.Checkout.Session;

  console.log("SESSION ID:", session.id);

  const { data, error } = await supabase
    .from("orders_new")
    .update({
      status: "paid",
    })
    .eq("stripe_session_id", session.id);

  console.log("UPDATE DATA:", data);
  console.log("UPDATE ERROR:", error);
}

    return NextResponse.json({ received: true });
  } catch (err) {
    console.error(err);

    return NextResponse.json(
      { error: "Webhook failed" },
      { status: 400 }
    );
  }
}