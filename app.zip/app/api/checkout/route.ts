import { NextResponse } from "next/server";
import Stripe from "stripe";
import { createClient } from "@supabase/supabase-js";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

export async function POST(req: Request) {
  try {
    const {
  cart,
  referralEmail,
  email,
  firstName,
  lastName,
  phone,
  street,
  zip,
  city,
  country,
  notes,
} = await req.json();
    console.log("Referral Email:", referralEmail);
    const totalAmount = cart.reduce(
  (sum: number, item: any) =>
    sum + item.price * item.quantity,
  0
);

const orderItems = JSON.stringify(cart);

    const line_items = cart.map((item: any) => ({
      price_data: {
        currency: "chf",
        product_data: {
          name: item.name,
       images: [],
        },
        unit_amount: Math.round(item.price * 100),
      },
      quantity: item.quantity,
    }));
const session = await stripe.checkout.sessions.create({
  payment_method_types: ["card"],
  line_items,
  mode: "payment",
  customer_email: email,

  success_url: `${req.headers.get("origin")}/success`,
  cancel_url: `${req.headers.get("origin")}/checkout`,
});

const { data, error } = await supabase
  .from("orders_new")
  .insert([
{
  customer_email: email,
  referral_email: referralEmail || null,

  first_name: firstName,
  last_name: lastName,
  phone,
  street,
  zip,
  city,
  country,
  notes,

 amount: totalAmount,
status: "pending",
stripe_session_id: session.id,

items: orderItems,
},
])

console.log("ORDER DATA:", data);
console.log("ORDER ERROR:", error);

    return NextResponse.json({
      url: session.url,
    });
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      { error: "Stripe session failed" },
      { status: 500 }
    );
  }
}